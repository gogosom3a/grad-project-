import CdiForm from "@/components/CdiForm";
import React from "react";

function CDIData() {
  return <CdiForm />;
}

export default CDIData;
